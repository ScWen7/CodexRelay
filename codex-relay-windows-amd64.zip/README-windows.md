# Codex Relay Windows CLI Preview

Windows 版本目前是 CLI preview，暂不包含图形界面、托盘、安装器和远程控制能力。

## 预览方式

```powershell
.\codex-relay.exe setup
.\codex-relay.exe doctor
.\codex-relay.exe status
```

手动 zip 方式仅用于 preview、早期测试和问题排查。正式 CLI 体验会使用安装脚本、PATH 和 `cr` 短命令。

## 日常命令目标

```powershell
cr setup
cr doctor
cr status
cr profile list
cr profile add work
cr profile switch work
cr profile sync work
```

## 当前限制

- 不包含 Windows Tray App。
- 不包含 MSI / MSIX 安装器。
- 切换 profile 前请先关闭 Codex。
- 如果命令提示 Codex 正在运行，请关闭 Codex 后重试。
